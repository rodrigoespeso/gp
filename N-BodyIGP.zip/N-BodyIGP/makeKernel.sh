. /opt/mpss/3.8.3/environment-setup-k1om-mpss-linux
make -C /home/rodrigo/mpss-3.8.3/src/newtests/tfgkernel-mod4ro/ ARCH=k1om CROSS_COMPILE=k1om-mpss-linux- -j4
