cd /home/rodrigo/N-Body-Phi-KST-CRIT/
