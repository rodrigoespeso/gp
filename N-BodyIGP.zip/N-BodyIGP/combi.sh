. makeKernel.sh
. rebootMic.sh