./nbody_pthread 1 1000 test20000.txt
./nbody_pthread 960 1000 test20000.txt
