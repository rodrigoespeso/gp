micctrl --reboot
. kstToMic.sh